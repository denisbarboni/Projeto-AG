# Genetic algorithm in CoffeeScript

An implementation of a Genetic Algorithm that 'solves' the Travelling Salesman Problem.

[The talk on Genetic Algorithms](http://janmonschke.com/Genetic-Algorithms/presentation)

[The demo](http://janmonschke.com/Genetic-Algorithms)